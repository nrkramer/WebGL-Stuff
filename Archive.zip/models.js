function Model(vertices) {
	this.vertices = vertices;
	this.colors = null;
	this.xRot = 0;
	this.yRot = 0;
	this.zRot = 0;
	this.xPos = 0;
	this.yPos = 0;
	this.zPos = 0;
	this.vertexBuffId = null;
	this.colorBuffId = null;
}

Model.prototype.bufferData = function() {
	// Buffer vertex data
	this.vertexBuffId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(this.vertices), gl.STATIC_DRAW);

	// Buffer color data if it exists
	if (this.colors != null) {
		this.colorBuffId = gl.createBuffer();
		gl.bindBuffer(gl.ARRAY_BUFFER, this.colorBuffId);
		gl.bufferData(gl.ARRAY_BUFFER, flatten(this.colors), gl.STATIC_DRAW);
	}
}

Model.prototype.getMatrix = function() {
	return mult(translate(this.xPos, this.yPos, this.zPos), mult(mult(rotate(this.xRot, vec3(1, 0, 0)), rotate(this.yRot, vec3(0, 1, 0))), rotate(this.zRot, vec3(0, 0, 1))));
}

Model.prototype.drawModel = function() {
	// rebind model vertices and color
	gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffId);
	gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
	gl.bindBuffer(gl.ARRAY_BUFFER, this.colorBuffId);
	gl.vertexAttribPointer(vVertexColor, 4, gl.FLOAT, false, 0, 0);

	// draw
	gl.drawArrays(gl.TRIANGLES, 0, this.vertices.length / 3);
}

var pyramid = new Model([
	-1.0, -1.0, 1.0,
	0.0, 1.0, 0.0,
	1.0, -1.0, 1.0,
	1.0, -1.0, 1.0,
	0.0, 1.0, 0.0,
	1.0, -1.0, -1.0,
	1.0, -1.0, -1.0,
	0.0, 1.0, 0.0,
	-1.0, -1.0, -1.0,
	-1.0, -1.0, -1.0,
	0.0, 1.0, 0.0,
	-1.0, -1.0, 1.0,
	-1.0, -1.0, 1.0,
	-1.0, -1.0, -1.0,
	1.0, -1.0, -1.0,
	1.0, -1.0, -1.0,
	1.0, -1.0, 1.0,
	-1.0, -1.0, 1.0
]);
pyramid.colors = [
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0
];
pyramid.zPos = -10.0;
pyramid.xPos = -5.0;
pyramid.yPos = 2.0;

/*1) 1.045361, 0.017499, -0.468442
2) -0.655940, 0.017499, -0.468442
3) 1.045361, 0.017499, 0.583020
4) -0.655940, 0.017499, 0.583020
5) 0.720442, 0.868150, 0.057289
6) 0.720442, -0.833152, 0.057289
7) -0.331021, 0.868150, 0.057289
8) -0.331021, -0.833152, 0.057289
9) 0.194711, 0.543230, -0.793362
10) 0.194711, 0.543230, 0.907939
11) 0.194711, -0.508232, -0.793362
12) 0.194711, -0.508232, 0.907939 */
var d20 = new Model([
	1.045361, 0.017499, -0.468442,
	0.194711, 0.543230, -0.793362,
	0.720442, 0.868150, 0.057289,
	-0.655940, 0.017499, -0.468442,
	0.720442, -0.833152, 0.057289,
	0.194711, -0.508232, -0.793362,
	1.045361, 0.017499, 0.583020,
	0.720442, 0.868150, 0.057289,
	0.194711, 0.543230, 0.907939,
	-0.655940, 0.017499, 0.583020,
	0.194711, -0.508232, 0.907939,
	0.720442, -0.833152, 0.057289,
	0.720442, 0.868150, 0.057289,
	-0.331021, 0.868150, 0.057289,
	0.194711, 0.543230, -0.793362,
	0.720442, -0.833152, 0.057289,
	0.194711, -0.508232, -0.793362,
	-0.331021, -0.833152, 0.057289
]);
d20.colors = [
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0,
	1.0, 0.0, 0.0, 1.0,
	0.0, 1.0, 0.0, 1.0,
	0.0, 0.0, 1.0, 1.0
];
d20.zPos = -10.0;
d20.xPos = 5.0;
d20.yPos = 2.0;

var models = [pyramid, d20];
